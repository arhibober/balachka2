#
# phpBB Backup Script
# Dump of tables for phpbb_
# DATE : 25-01-2012 05:39:08 GMT
#
# Table: phpbb_acl_groups
DROP TABLE IF EXISTS phpbb_acl_groups;
CREATE TABLE `phpbb_acl_groups` (
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `auth_option_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `auth_role_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `auth_setting` tinyint(2) NOT NULL DEFAULT '0',
  KEY `group_id` (`group_id`),
  KEY `auth_opt_id` (`auth_option_id`),
  KEY `auth_role_id` (`auth_role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO phpbb_acl_groups (group_id, forum_id, auth_option_id, auth_role_id, auth_setting) VALUES (1, 0, 85, 0, 1),(1, 0, 93, 0, 1),(1, 0, 111, 0, 1),(5, 0, 0, 5, 0),(5, 0, 0, 1, 0),(2, 0, 0, 6, 0),(3, 0, 0, 6, 0),(4, 0, 0, 5, 0),(4, 0, 0, 10, 0),(1, 1, 0, 17, 0),(2, 1, 0, 15, 0),(3, 1, 0, 15, 0),(6, 1, 0, 17, 0),(5, 4, 0, 14, 0),(6, 4, 0, 17, 0),(3, 4, 0, 15, 0),(2, 4, 0, 15, 0),(7, 0, 0, 23, 0),(1, 4, 0, 17, 0),(5, 1, 0, 14, 0),(1, 10, 0, 17, 0),(2, 10, 0, 15, 0),(3, 10, 0, 15, 0),(6, 10, 0, 17, 0),(5, 10, 0, 14, 0),(1, 11, 0, 17, 0),(2, 11, 0, 15, 0),(3, 11, 0, 15, 0),(6, 11, 0, 17, 0),(5, 11, 0, 14, 0);

